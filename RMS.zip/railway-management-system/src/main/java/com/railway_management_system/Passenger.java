
package com.railway_management_system;

import java.util.Currency;

/**
 *
 * @author Shamika Tissera
 */
public class Passenger extends User{
    boolean isPriorityCustomer; // status
    Currency credit_available;
}
